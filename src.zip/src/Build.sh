#!/bin/sh
javac -encoding utf-8 *.java

